
<?php $__env->startSection('title'); ?>
View Daftar Hadir Undangan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">View Daftar Hadir Undangan</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">View Daftar Hadir Undangan</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">View Daftar Hadir Undangan</div>
    <div class="card-body">
      <div class="form-group">
        <form action="<?php echo e(url('LaporanAbsensiUndangan')); ?>" method="post" accept-charset="utf-8">
          <?php echo csrf_field(); ?>
        <input type="" name="cities" value="<?php echo e($cities); ?>" style="display: none;">
        <input type="" name="tahun" value="<?php echo e($tahun); ?>" style="display: none;">
        <label>Hari :</label>
        <input type="text" name="hari" value="<?php echo e($hari); ?>" class="form-control">
        <label>Tanggal :</label>
        <input type="text" name="tanggal" value="<?php echo e($tanggal); ?>" class="form-control">
        <label>Tempat :</label>
        <input type="text" name="tempat" value="<?php echo e($tempat->cities->name); ?>" class="form-control" >
      </div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jabatan</th>
            <th colspan="2">Tanda Tangan</th>
          </tr>
        </thead>
        <tbody>
          <?php for($i = 1; $i <=20 ; $i++): ?>
           <tr>
             <td><?php echo e($i); ?></td>
             <td></td>
             <td></td>
             <td>
               <?php if($i % 2 == 0): ?>
                 
                 <?php else: ?>
                 <?php echo e($i); ?>

               <?php endif; ?>
             </td>
             <td>
               <?php if($i % 2 == 1): ?>
                 
                 <?php else: ?>
                 <?php echo e($i); ?>

               <?php endif; ?>
             </td>
           </tr>
          <?php endfor; ?>
        </tbody>
      </table>
      <div class="card-footer">
          <button type="submit" class="btn btn-danger"><i class="fa fa-print"></i>Print</button>
        </form>
        <a href="<?php echo e(url('Laporan')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/ViewDaftarHadirUndangan.blade.php ENDPATH**/ ?>