<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Laporan Daftar Hadir Permakanan</title>
	<link rel="stylesheet" href="">
	<style type="text/css" media="screen">
		body{
			font-family: sans-serif;
		}
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
      padding:  6px;
      width: 100%;
		}
    h4, h3 {
      text-align: center;
    }
    .ttd1{
      margin-top: 15px;
      text-align: center;
      margin-right: 60%;
      font-size: 12px;
    }
    .ttd2{
      margin-top: -36px;
      margin-left: 55%;
      text-align: center;
      font-size: 12px;
    }
	</style>
</head>
<body>
	<h3>DAFTAR HADIR PELAJARAN</h3>
  <h4>PELATIHAN PENINGKATAN KETERAMPILAN KERJA MANDIRI <br> 
    TAHUN <?php echo e($tempat->angkatan); ?></h4>
    <h4>DI <?php echo e($tempat->cities->name); ?></h4>  
    <hr>
    <label>Tempat :</label><?php echo e($tempat->cities->name); ?> <br>
    <label>Peminatan :</label><?php echo e($peminatan); ?>

	<table>
        <thead>
          <tr>
            <th rowspan="4">No</th>
            <th rowspan="4">Nama Peserta</th>
            <th colspan="6" style="width: 500px;">Jadwal Pelajaran</th>
          </tr>
          <tr>
            <th colspan="6" style="width: 500px;"><?php echo e($hari); ?>/<?php echo e($tanggal); ?></th>
          </tr>
          <tr>
            <th>
              <?php echo e($jam_awal_1); ?> -
              <?php echo e($jam_akhir_1); ?>

            </th>
            <th>
              <?php echo e($jam_awal_2); ?>-
              <?php echo e($jam_akhir_2); ?>

            </th>
            <th>
              <?php echo e($jam_awal_3); ?>-
              <?php echo e($jam_akhir_3); ?>

            </th>
            <th>
              <?php echo e($jam_awal_4); ?>-
              <?php echo e($jam_akhir_4); ?>

            </th>
            <th>
              <?php echo e($jam_awal_5); ?>-
              <?php echo e($jam_akhir_5); ?>

            </th>
            <th>
              <?php echo e($jam_awal_6); ?>-
              <?php echo e($jam_akhir_6); ?>

            </th>
          </tr>
          <tr>
            <th>
              <?php echo e($nama_pertemuan_1); ?>

            </th>
            <th>
             <?php echo e($nama_pertemuan_2); ?>

            </th>
            <th>
              <?php echo e($nama_pertemuan_3); ?>

            </th>
            <th>
              <?php echo e($nama_pertemuan_4); ?>

            </th>
            <th>
              <?php echo e($nama_pertemuan_5); ?>

            </th>
            <th>
              <?php echo e($nama_pertemuan_6); ?>

            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
             <td><?php echo e($loop->iteration); ?></td>
             <td><?php echo e($element->nama); ?></td>
             <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="ttd1">
      Mengetahui : <br>
      Kepala Seksi Penyelenggaraan Pelatihan,
    </div>

    <div class="ttd2">
      Bandung, ............... <?php echo e($tahun); ?><br>
      Urusan Administrasi,
    </div>
</body>
</html><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/LaporanDaftarHadirPelajaran.blade.php ENDPATH**/ ?>