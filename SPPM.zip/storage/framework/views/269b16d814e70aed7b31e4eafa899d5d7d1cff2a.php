
<?php $__env->startSection('title'); ?>
Daftar Hadir Permakanan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Daftar Hadir Permakanan</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Daftar Hadir Permakanan</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">Daftar Hadir Permakanan</div>
    <div class="card-body">
      <div class="form-group">
        <form action="<?php echo e(url('LaporanDaftarHadirPermakanan')); ?>" method="post" accept-charset="utf-8">
          <?php echo csrf_field(); ?>
        <input type="" name="cities" value="<?php echo e($cities); ?>" style="display: none;">
        <input type="" name="tahun" value="<?php echo e($tahun); ?>" style="display: none;">
        <label>Tempat :</label>
        <input type="text" name="tempat" value="<?php echo e($tempat->cities->name); ?>" class="form-control" >
        <label>Peminatan :</label>
        <input type="text" name="peminatan" value="<?php echo e($peminatan); ?>" class="form-control" >
      </div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th rowspan="3">No</th>
            <th rowspan="3">Nama</th>
            <th colspan="15">Tanda Tangan</th>
          </tr>
          <tr>
            <th colspan="5">
              <input type="text" name="hari_1" value="<?php echo e($hari1); ?>">/
              <input type="date" name="tanggal_1" value="<?php echo e($tanggal1); ?>">
            </th>
            <th colspan="5">
              <input type="text" name="hari_2" value="<?php echo e($hari2); ?>">/
              <input type="date" name="tanggal_2" value="<?php echo e($tanggal2); ?>">
            </th>
            <th colspan="5">
              <input type="text" name="hari_3" value="<?php echo e($hari3); ?>">/
              <input type="date" name="tanggal_3" value="<?php echo e($tanggal3); ?>">
            </th>
          </tr>
          <tr>
            <th>Pagi</th>
            <th>Snack</th>
            <th>Siang</th>
            <th>Snack</th>
            <th>Malam</th>
            <th>Pagi</th>
            <th>Snack</th>
            <th>Siang</th>
            <th>Snack</th>
            <th>Malam</th>
            <th>Pagi</th>
            <th>Snack</th>
            <th>Siang</th>
            <th>Snack</th>
            <th>Malam</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
             <td><?php echo e($loop->iteration); ?></td>
             <td><?php echo e($element->nama); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="card-footer">
          <button type="submit" class="btn btn-danger"><i class="fa fa-print"></i>Print</button>
        </form>
        <a href="<?php echo e(url('Laporan')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/ViewDaftarHadirPermakanan.blade.php ENDPATH**/ ?>