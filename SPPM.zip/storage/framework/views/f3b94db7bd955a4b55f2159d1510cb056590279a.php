<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Laporan Biodata</title>
  <link rel="stylesheet" href="">
  <style type="text/css" media="screen">
    body{

    }
    h2{
      text-align: center;
      font-family: sans-serif;
    }
    h3{
      text-align: center;
      font-family: sans-serif;
    }
    table{
      font-size: 20px;
      text-align: left;
      margin-left: 30px;
      font-family: sans-serif;
    }
    td{
      padding-left: 30px;
      text-align: left;
    }
    th{
      text-align: left;
    }
    .ttd{
      margin-left: 540px;
      text-align: center;
      font-size: 20px;
    }
  </style>
</head>
<body>
  <h2>BIODATA PESERTA</h2>
  <h3>PELATIHAN PENINGKATAN KETERAMPILAN KERJA MANDIRI <br> 
    TAHUN <?php echo e($formulir->angkatan); ?></h3>  
    <hr> 
      <table>
        <thead>
          <tr>
            <th>Nama</th>
            <td><?php echo e($formulir->nama); ?></td>
          </tr>
          <tr>
            <th>Umur</th>
            <td><?php echo e($formulir->umur); ?></td>
          </tr>
          <tr>
            <th>Tempat, Tanggal Lahir</th>
            <td><?php echo e($formulir->ttl); ?></td>
          </tr>
          <tr>
            <th>Alamat</th>
            <td><?php echo e($formulir->alamat); ?></td>
          </tr>
          <tr>
            <th></th>
            <td style="font-weight: bold;">Provinsi</td>
            <td><?php echo e($formulir->provinces->name); ?></td>
          </tr>
          <tr>
            <th></th>
            <td style="font-weight: bold;">Kota/Kabupaten</td>
            <td><?php echo e($formulir->cities->name); ?></td>
          </tr>
          <tr>
            <th></th>
            <td style="font-weight: bold;">Kecamatan</td>
            <td><?php echo e($formulir->districts->name); ?></td>
          </tr>
          <tr>
            <th></th>
            <td style="font-weight: bold;">Kelurahan</td>
            <td><?php echo e($formulir->villages->name); ?></td>
          </tr>
          <tr>
            <th>No Kartu Keluarga</th>
            <td><?php echo e($formulir->no_kk); ?></td>
          </tr>
          <tr>
            <th>No KTP</th>
            <td><?php echo e($formulir->no_ktp); ?></td>
          </tr>
          <tr>
            <th>Jenis Kelamin</th>
            <td><?php echo e($formulir->jenis_kelamin); ?></td>
          </tr>
          <tr>
            <th>Pekerjaan</th>
            <td><?php echo e($formulir->pekerjaan); ?></td>
          </tr>
          <tr>
            <th>Pendidikan</th>
            <td><?php echo e($formulir->pendidikan); ?></td>
          </tr>
          <tr>
            <th>Angkatan</th>
            <td><?php echo e($formulir->angkatan); ?></td>
          </tr>
          <tr>
            <th>No HP</th>
            <td><?php echo e($formulir->no_hp); ?></td>
          </tr>
          <tr>
            <th>No Rekening</th>
            <td><?php echo e($formulir->no_rek); ?></td>
          </tr>
          <tr>
            <th>Bank</th>
            <td><?php echo e($formulir->bank); ?></td>
          </tr>
          <tr>
            <th>Atas Nama</th>
            <td><?php echo e($formulir->atas_nama); ?></td>
          </tr>
          <tr>
            <th>Peminatan</th>
            <td><?php echo e($formulir->peminatan); ?></td>
          </tr>
        </table> <br>
      <div class="ttd">
        ..... , ................<?php echo e($formulir->angkatan); ?><br>
        Peserta, <br><br><br><br>
        <?php echo e($formulir->nama); ?>

      </div>
    </body>
    </html><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/LaporanBiodata.blade.php ENDPATH**/ ?>