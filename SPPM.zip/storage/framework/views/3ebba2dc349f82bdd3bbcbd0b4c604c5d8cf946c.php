
<?php $__env->startSection('title'); ?>
Edit Pengumuman
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Edit Pengumuman</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Edit Pengumuman</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="container">
   <form action="<?php echo e(url('Pengumuman/'.$pengumuman->id)); ?>" method="post" accept-charset="utf-8">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="card">
    <div class="card-header">
        <h3 class="card-title">Edit Data Pengumuman</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="form-group">
          <label>Judul</label>
          <input type="text" placeholder="Judul Pengumuman" class="form-control" name="judul" value="<?php echo e($pengumuman->judul); ?>" required>
        </div>
        <div class="form-group">
          <label>Isi</label>
          <textarea name="isi" placeholder="Isi Pengumuman" class="textarea" rows="5" required><?php echo e($pengumuman->isi); ?></textarea>
        </div>
        <div class="card-footer">
          <button class="btn btn-primary"><i class="fas fa-save mr-1"></i>Simpan</button>
          <a class="btn btn-default" href="<?php echo e(url('Pengumuman')); ?>"><i class="fa fa-undo mr-1"></i>Kembali</a>
        </div>
    </div>
    <!-- /.card-body -->
</div>
  </form>
  </div>  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/EditPengumuman.blade.php ENDPATH**/ ?>