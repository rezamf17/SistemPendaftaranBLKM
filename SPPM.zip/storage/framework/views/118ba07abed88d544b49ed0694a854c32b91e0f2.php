
<?php $__env->startSection('title'); ?>
View Sertifikat
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">View Sertifikat</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">View Sertifikat</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">View Sertifikat</div>
    <div class="card-body">
      <div class="form-group">
        <form action="<?php echo e(url('LaporanSertifikat/'.$formulir->id)); ?>" method="post" accept-charset="utf-8">
          <?php echo csrf_field(); ?>
        <label>Nomor Sertifikat</label>
        <input type="text" name="nomor" value="<?php echo e($nomor); ?>" class="form-control">
        <label>Nama</label>
        <input type="text" name="nama" value="<?php echo e($formulir->nama); ?>" class="form-control">
        <label>Tempat, Tanggal Lahir</label>
        <input type="text" name="ttl" value="<?php echo e($formulir->ttl); ?>" class="form-control">
        <label>Alamat</label>
        <textarea name="alamat" class="form-control"><?php echo e($formulir->alamat); ?>, <?php echo e($formulir->villages->name); ?>, <?php echo e($formulir->districts->name); ?>, <?php echo e($formulir->cities->name); ?></textarea>
        <label>Tempat Pelatihan</label>
        <input type="text" name="tempat" value="<?php echo e($tempat); ?>" class="form-control">
        <label>Tanggal Mulai Pelatihan</label>
        <input type="text" name="mulai" value="<?php echo e($mulai); ?>" class="form-control">
        <label>Tanggal Selesai Pelatihan</label>
        <input type="text" name="selesai" value="<?php echo e($selesai); ?>" class="form-control">
        <label>Tahun</label>
        <input type="" name="tahun" value="<?php echo e($tahun); ?>" class="form-control">
        <label>Peminatan :</label>
        <input type="text" name="peminatan" value="<?php echo e($formulir->peminatan); ?>" class="form-control" >
      </div>
      
      <div class="card-footer">
          <button type="submit" class="btn btn-danger"><i class="fa fa-print"></i>Print</button>
        </form>
        <a href="<?php echo e(url('Laporan')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/ViewSertifikat.blade.php ENDPATH**/ ?>