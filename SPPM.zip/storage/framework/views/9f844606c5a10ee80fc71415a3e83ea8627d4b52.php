
<?php $__env->startSection('title'); ?>
Daftar Hadir Pelajaran
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Daftar Hadir Pelajaran</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Daftar Hadir Pelajaran</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">Daftar Hadir Pelajaran</div>
    <div class="card-body">
      <div class="form-group">
        <form action="<?php echo e(url('LaporanDaftarHadirPelajaran')); ?>" method="post" accept-charset="utf-8">
          <?php echo csrf_field(); ?>
        <input type="" name="cities" value="<?php echo e($cities); ?>" style="display: none;">
        <input type="" name="tahun" value="<?php echo e($tahun); ?>" style="display: none;">
        <label>Tempat :</label>
        <input type="text" name="tempat" value="<?php echo e($tempat->cities->name); ?>" class="form-control" >
        <label>Peminatan :</label>
        <input type="text" name="peminatan" value="<?php echo e($peminatan); ?>" class="form-control" >
      </div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th rowspan="4">No</th>
            <th rowspan="4">Nama Peserta</th>
            <th colspan="6">Jadwal Pelajaran</th>
          </tr>
          <tr>
            <th colspan="6">
            <input type="text" name="hari" value="<?php echo e($hari); ?>">/
            <input type="text" name="tanggal" value="<?php echo e($tanggal); ?>"></th>
          </tr>
          <tr>
            <th>
              <input type="text" name="jam_awal_1" value="<?php echo e($jam_awal_1); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_1" value="<?php echo e($jam_akhir_1); ?>" style="width: 50px;">
            </th>
            <th>
              <input type="text" name="jam_awal_2" value="<?php echo e($jam_awal_2); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_2" value="<?php echo e($jam_akhir_2); ?>" style="width: 50px;">
            </th>
            <th>
              <input type="text" name="jam_awal_3" value="<?php echo e($jam_awal_3); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_3" value="<?php echo e($jam_akhir_3); ?>" style="width: 50px;">
            </th>
            <th>
              <input type="text" name="jam_awal_4" value="<?php echo e($jam_awal_4); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_4" value="<?php echo e($jam_akhir_4); ?>" style="width: 50px;">
            </th>
            <th>
              <input type="text" name="jam_awal_5" value="<?php echo e($jam_awal_5); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_5" value="<?php echo e($jam_akhir_5); ?>" style="width: 50px;">
            </th>
            <th>
              <input type="text" name="jam_awal_6" value="<?php echo e($jam_awal_6); ?>" style="width: 50px;"> -
              <input type="text" name="jam_akhir_6" value="<?php echo e($jam_akhir_6); ?>" style="width: 50px;">
            </th>
          </tr>
          <tr>
            <th>
              <input type="text" name="nama_pertemuan_1" value="<?php echo e($nama_pertemuan_1); ?>" style="width: 110px;">
            </th>
            <th>
              <input type="text" name="nama_pertemuan_2" value="<?php echo e($nama_pertemuan_2); ?>" style="width: 110px;">
            </th>
            <th>
              <input type="text" name="nama_pertemuan_3" value="<?php echo e($nama_pertemuan_3); ?>" style="width: 110px;">
            </th>
            <th>
              <input type="text" name="nama_pertemuan_4" value="<?php echo e($nama_pertemuan_4); ?>" style="width: 110px;">
            </th>
            <th>
              <input type="text" name="nama_pertemuan_5" value="<?php echo e($nama_pertemuan_5); ?>" style="width: 110px;">
            </th>
            <th>
              <input type="text" name="nama_pertemuan_6" value="<?php echo e($nama_pertemuan_6); ?>" style="width: 110px;">
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
             <td><?php echo e($loop->iteration); ?></td>
             <td><?php echo e($element->nama); ?></td>
             <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="card-footer">
          <button type="submit" class="btn btn-danger"><i class="fa fa-print"></i>Print</button>
        </form>
        <a href="<?php echo e(url('Laporan')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/ViewDaftarHadirPelajaran.blade.php ENDPATH**/ ?>