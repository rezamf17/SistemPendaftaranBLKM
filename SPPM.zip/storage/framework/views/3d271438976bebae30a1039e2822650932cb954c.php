
<?php $__env->startSection('title'); ?>
Lihat Formulir
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Lihat Formulir</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Lihat Formulir</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="container">
  <div class="card">
    <div class="card-header">Data Formulir : <?php echo e($formulir->nama); ?></div>
      <div class="card-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Nama</th>
              <td><?php echo e($formulir->nama); ?></td>
            </tr>
            <tr>
              <th>Tempat, Tanggal Lahir</th>
              <td><?php echo e($formulir->ttl); ?></td>
            </tr>
            <tr>
              <th>Alamat</th>
              <td><?php echo e($formulir->alamat); ?></td>
            </tr>
            <tr>
              <th>Provinsi</th>
              <td><?php echo e($formulir->provinces->name); ?></td>
            </tr>
            <tr>
              <th>Kota/Kabupaten</th>
              <td><?php echo e($formulir->cities->name); ?></td>
            </tr>
            <tr>
              <th>Kecamatan</th>
              <td><?php echo e($formulir->districts->name); ?></td>
            </tr>
            <tr>
              <th>Kelurahan</th>
              <td><?php echo e($formulir->villages->name); ?></td>
            </tr>
            <tr>
              <th>No Kartu Keluarga</th>
              <td><?php echo e($formulir->no_kk); ?></td>
            </tr>
            <tr>
              <th>No KTP</th>
              <td><?php echo e($formulir->no_ktp); ?></td>
            </tr>
            <tr>
              <th>Jenis Kelamin</th>
              <td><?php echo e($formulir->jenis_kelamin); ?></td>
            </tr>
            <tr>
              <th>Pekerjaan</th>
              <td><?php echo e($formulir->pekerjaan); ?></td>
            </tr>
            <tr>
              <th>No HP</th>
              <td><?php echo e($formulir->no_hp); ?></td>
            </tr>
            <tr>
              <th>No Rekening</th>
              <td><?php echo e($formulir->no_rek); ?></td>
            </tr>
            <tr>
              <th>Bank</th>
              <td><?php echo e($formulir->bank); ?></td>
            </tr>
            <tr>
              <th>Atas Nama</th>
              <td><?php echo e($formulir->atas_nama); ?></td>
            </tr>
            <tr>
              <th>Peminatan</th>
              <td><?php echo e($formulir->peminatan); ?></td>
            </tr>
            <tr>
              <th>Foto KTP</th>
              <td><img width="150px" src="<?php echo e(url('/data_file/'.$formulir->foto_ktp)); ?>"></td>
            </tr>
        </table>
        </div>
        <div class="card-footer">
          <a href="<?php echo e(url('UserFormulir/'.$formulir->id_user.'/edit')); ?>" class="btn btn-success"><i class="fa fa-edit"></i>Ganti Data</a>
          <a href="<?php echo e(url('user')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
        </div>
      </div>
    </div>
  </div>
</div>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/user/LihatFormulir.blade.php ENDPATH**/ ?>