
<?php $__env->startSection('title'); ?>
Kelola Akun
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Kelola Akun</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Kelola Akun</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-xl">
        <i class="fa fa-plus"></i> Tambah Akun
      </button>
      
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Nomor HP</th>
            <th>Level</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->phone); ?></td>
            <td><?php if($item->role == 1): ?>
              Admin
              <?php elseif($item->role == 2): ?>
              User
              <?php else: ?>
              -
              <?php endif; ?>
            </td>
            <td><?php echo e($item->status); ?></td>
            <th>
              <a href="<?php echo e(url('KelolaAkun/'.$item->id.'/edit')); ?>" title="" class="btn btn-success"> 
                <i class="fa fa-edit"></i>Edit</a>
                <form action="<?php echo e(url('KelolaAkun', $item->id)); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin hapus data?')">
                  <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>Hapus
                  </button>
                </form>
              </th>     
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>

    <div class="modal fade" id="modal-xl">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Tambah Data Akun</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="<?php echo e(url('KelolaAkun')); ?>" method="POST">

              <div class="form-group">
                <?php echo csrf_field(); ?>
                <label>Nama Lengkap</label>
                <input type="text" name="name" class="form-control" placeholder="Nama Lengkap" required>
              </div>
              <div class="form-group">
                <label>Nomor HP</label>
                <input type="number" name="phone" class="form-control" placeholder="Nomor HP" required>
              </div>
              <div class="form-group">
                <label>Level</label>
                <select name="role" class="form-control" required>
                  <option value="">--Pilih Level--</option>
                  <option value="1">Admin</option>
                  <option value="2">User</option>
                </select>
              </div>

              </select>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control"  placeholder="Password" required>
              </div>
              <div class="form-group">
                <label>Konfirmasi Password</label>
                <input type="password" name="password_confirmation" class="form-control"  placeholder="Konfirmasi Password" required>
              </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <input type="submit" class="btn btn-primary" value="Simpan" name="">
            </form>
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/KelolaAkun.blade.php ENDPATH**/ ?>