<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Report Data User</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<table class="table table-bordered">
          <thead>
            <tr>
              <th>Nama</th>
              <td><?php echo e($formulir->nama); ?></td>
            </tr>
            <tr>
              <th>Tempat, Tanggal Lahir</th>
              <td><?php echo e($formulir->ttl); ?></td>
            </tr>
            <tr>
              <th>Alamat</th>
              <td><?php echo e($formulir->alamat); ?></td>
            </tr>
            <tr>
              <th>Provinsi</th>
              <td><?php echo e($formulir->provinces->name); ?></td>
            </tr>
            <tr>
              <th>Kota/Kabupaten</th>
              <td><?php echo e($formulir->cities->name); ?></td>
            </tr>
            <tr>
              <th>Kecamatan</th>
              <td><?php echo e($formulir->districts->name); ?></td>
            </tr>
            <tr>
              <th>Kelurahan</th>
              <td><?php echo e($formulir->villages->name); ?></td>
            </tr>
            <tr>
              <th>No Kartu Keluarga</th>
              <td><?php echo e($formulir->no_kk); ?></td>
            </tr>
            <tr>
              <th>No KTP</th>
              <td><?php echo e($formulir->no_ktp); ?></td>
            </tr>
            <tr>
              <th>Jenis Kelamin</th>
              <td><?php echo e($formulir->jenis_kelamin); ?></td>
            </tr>
            <tr>
              <th>Pekerjaan</th>
              <td><?php echo e($formulir->pekerjaan); ?></td>
            </tr>
            <tr>
              <th>No HP</th>
              <td><?php echo e($formulir->no_hp); ?></td>
            </tr>
            <tr>
              <th>No Rekening</th>
              <td><?php echo e($formulir->no_rek); ?></td>
            </tr>
            <tr>
              <th>Bank</th>
              <td><?php echo e($formulir->bank); ?></td>
            </tr>
            <tr>
              <th>Atas Nama</th>
              <td><?php echo e($formulir->atas_nama); ?></td>
            </tr>
            <tr>
              <th>Peminatan</th>
              <td><?php echo e($formulir->peminatan); ?></td>
            </tr>
            <tr>
              <th>Status</th>
              <td><?php echo e($formulir->status); ?></td>
            </tr>
        </table>
</body>
</html><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/DataUserLaporan.blade.php ENDPATH**/ ?>