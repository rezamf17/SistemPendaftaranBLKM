
<?php $__env->startSection('title'); ?>
Berita Pengumuman
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="card">
	<div class="card-header">
		<h3>Berita Pengumuman</h3>
	</div>
</div>
<?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card">
	<div class="card-header">
		<h3><?php echo e($element->judul); ?></h3>
	</div>
	<div class="card-body">
	<?php echo $element->isi; ?>

	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/pengumuman.blade.php ENDPATH**/ ?>