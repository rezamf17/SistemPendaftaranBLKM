
<?php $__env->startSection('title'); ?>
View Tanda Terima Perlengkapan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">View Tanda Terima Perlengkapan</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">View Tanda Terima Perlengkapan</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">View Tanda Terima Perlengkapan</div>
    <div class="card-body">
      <div class="form-group">
        <form action="<?php echo e(url('LaporanTandaTerimaPerlengkapan')); ?>" method="post" accept-charset="utf-8">
          <?php echo csrf_field(); ?>
        <input type="" name="cities" value="<?php echo e($cities); ?>" style="display: none;">
        <input type="" name="tahun" value="<?php echo e($tahun); ?>" style="display: none;">
        <label>Hari :</label>
        <input type="text" name="hari" value="<?php echo e($hari); ?>" class="form-control">
        <label>Tanggal :</label>
        <input type="text" name="tanggal" value="<?php echo e($tanggal); ?>" class="form-control">
        <label>Tempat :</label>
        <input type="text" name="tempat" value="<?php echo e($tempat->cities->name); ?>" class="form-control" >
        <label>Peminatan :</label>
        <input type="text" name="peminatan" value="<?php echo e($peminatan); ?>" class="form-control" >
        <label>Perlengkapan 1</label>
              <input type="text" name="perlengkapan_1" class="form-control" value="<?php echo e($perlengkapan_1); ?>">
            <label>Perlengkapan 2</label>
              <input type="text" name="perlengkapan_2" class="form-control" value="<?php echo e($perlengkapan_2); ?>">
            <label>Perlengkapan 3</label>
              <input type="text" name="perlengkapan_3" class="form-control" value="<?php echo e($perlengkapan_3); ?>">
            <label>Perlengkapan 4</label>
              <input type="text" name="perlengkapan_4" class="form-control" value="<?php echo e($perlengkapan_4); ?>">
            <label>Perlengkapan 5</label>
              <input type="text" name="perlengkapan_5" class="form-control" value="<?php echo e($perlengkapan_5); ?>">
            <label>Perlengkapan 6</label>
              <input type="text" name="perlengkapan_6" class="form-control" value="<?php echo e($perlengkapan_6); ?>">
      </div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Peserta</th>
            <th>Alamat Asal</th>
            <th>Perlengkapan</th>
            <th colspan="2">Tanda Tangan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($element->nama); ?></td>
              <td><?php echo e($element->alamat); ?>, 
                Desa/Kelurahan :<?php echo e($element->villages->name); ?>,
                Kecamatan :<?php echo e($element->districts->name); ?>,
                Kota/Kabupaten :<?php echo e($element->cities->name); ?></td>
              <td>1 Set</td>
              <td>
                <?php if($loop->even): ?>
                <?php else: ?>
                <?php echo e($loop->iteration); ?>.
                <?php endif; ?>
              </td>
              <td>
                <?php if($loop->odd): ?>
                <?php else: ?>
                <?php echo e($loop->iteration); ?>.
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="card-footer">
          <button type="submit" class="btn btn-danger"><i class="fa fa-print"></i>Print</button>
        </form>
        <a href="<?php echo e(url('Laporan')); ?>" class="btn btn-default"><i class="fa fa-repeat"></i>Batal</a>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/ViewTandaTerimaPerlengkapan.blade.php ENDPATH**/ ?>