
<?php $__env->startSection('title'); ?>
Data User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Data User</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Data User</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      Data User
      <div class="float-right"><a href="" title=""></a></div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Tempat, Tanggal Lahir</th>
            <th>Alamat</th>
            <th>Kota</th>
            
            
            <th>Jenis Kelamin</th>
            
            <th>No HP</th>
            
            
            <th>Peminatan</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->ttl); ?></td>
            <td><?php echo e($item->alamat); ?></td>
            <td><?php echo e($item->cities->name); ?></td>
            
            
            <td><?php echo e($item->jenis_kelamin); ?></td>
            
            <td><?php echo e($item->no_hp); ?></td>
            
            
            <td><?php echo e($item->peminatan); ?></td>
            <th>
             
                <a href="<?php echo e(url('Formulir/'.$item->id_user)); ?>" class="btn btn-primary"><i class="fa fa-eye"></i>Lihat</a>
              </th>     
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
        <!-- /.modal-content -->
      </div>
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/DataUser.blade.php ENDPATH**/ ?>