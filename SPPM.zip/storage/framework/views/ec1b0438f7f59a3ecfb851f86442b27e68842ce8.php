<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Laporan Tanda Terima Bahan Materi</title>
	<link rel="stylesheet" href="">
	<style type="text/css" media="screen">
		body{
			font-family: sans-serif;
		}
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding:  3px;
			font-size: 15px;
		}
		label{
			font-size: 15px;
			text-align: left;
		}
    h4, h3 {
      text-align: center;
    }
    .ttd1{
      margin-top: 15px;
      text-align: center;
      margin-right: 60%;
      font-size: 12px;
    }
    .ttd2{
      margin-top: -36px;
      margin-left: 55%;
      text-align: center;
      font-size: 12px;
    }
	</style>
</head>
<body>
	<h3>TANDA TERIMA BAHAN MATERI</h3>
  <h4>PELATIHAN PENINGKATAN KETERAMPILAN KERJA MANDIRI <br> 
    TAHUN <?php echo e($tahun); ?> <br> DI <?php echo e($tempat->cities->name); ?></h4>  
    <hr>
	<label>Hari : <?php echo e($hari); ?>/<?php echo e($tanggal); ?></label>  <br>
    <label>Tempat : <?php echo e($tempat->cities->name); ?></label> <br>
    <label>Peminatan : <?php echo e($peminatan); ?></label>
    <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Peserta</th>
            <th style="width: 340px;">Alamat Asal</th>
            <th>Foto Copy Materi</th>
            <th colspan="2">Tanda Tangan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $formulir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($element->nama); ?></td>
              <td><?php echo e($element->alamat); ?>, 
                Desa/Kelurahan :<?php echo e($element->villages->name); ?>,
                Kecamatan :<?php echo e($element->districts->name); ?>,
                Kota/Kabupaten :<?php echo e($element->cities->name); ?></td>
              <td>1 Set</td>
              <td style="width: 70px;">
                <?php if($loop->even): ?>
                <?php else: ?>
                <?php echo e($loop->iteration); ?>.
                <?php endif; ?>
              </td>
              <td style="width: 70px;">
                <?php if($loop->odd): ?>
                <?php else: ?>
                <?php echo e($loop->iteration); ?>.
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="ttd1">
      Mengetahui : <br>
      Kepala Seksi Penyelenggaraan Pelatihan,
    </div>

    <div class="ttd2">
      Bandung, ............... <?php echo e($tahun); ?><br>
      Urusan Administrasi,
    </div>
</body>
</html><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/laporan/LaporanTandaTerimaBahanMateri.blade.php ENDPATH**/ ?>