<div>
    <select name="provices" id="provinces" wire:model="provinceId">
        <option value="">Select Province</option>
        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if(!is_null($provinceId)): ?>
        <select>
            <option value="" selected>Select City</option>
            <?php $__currentLoopData = $cities->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php endif; ?>

</div><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/livewire/chain-dropdown.blade.php ENDPATH**/ ?>