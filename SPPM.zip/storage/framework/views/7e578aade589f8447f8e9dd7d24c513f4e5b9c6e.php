
<?php $__env->startSection('title'); ?>
Lengkapi Data
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Lengkapi Data</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Lengkapi Data</li>
        </ol>
    </div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="card">
    <div class="card-header">Lengkapi Data</div>
    <div class="card-body">
      <form action="<?php echo e(url('UserFormulir/lengkapi/'.$formulir->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" value="<?php echo e($formulir->nama); ?>" name="nama" disabled> 
        </div>
        <div class="form-group">
            <label>Tempat, Tanggal Lahir</label>
            <input type="text" class="form-control" name="ttl" value="<?php echo e($formulir->ttl); ?>" disabled>
            <i>*Contoh : Bandung, 18 April 1987</i>
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <textarea name="alamat" class="form-control" disabled><?php echo e($formulir->alamat); ?></textarea>
            <label>Provinsi</label>
            <?php
            $provinces = new App\Http\Controllers\DependentDropdownController;
            $provinces= $provinces->provinces();
            ?>
            <select class="form-control" name="provinsi" id="provinsi" disabled>
                <option>Pilih Provinsi</option>
                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id ?? ''); ?>" <?php echo e($formulir->id_provinces == $item->id ? 'selected' : ''); ?>><?php echo e($item->name ?? ''); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
             <label>Kota/Kabupaten</label>
            <select class="form-control" name="kota" id="kota" disabled>
              <option value="<?php echo e($formulir->id_cities); ?>"><?php echo e($formulir->cities->name); ?></option>
            </select>
            <label>Kecamatan</label>
            <select class="form-control" name="kecamatan" id="kecamatan" disabled>
              <option value="<?php echo e($formulir->id_districts); ?>"><?php echo e($formulir->districts->name); ?></option>
            </select>
            <label>Desa/Keluharan</label>
            <select class="form-control" name="desa" id="desa" disabled>
              <option value="<?php echo e($formulir->id_villages); ?>"><?php echo e($formulir->villages->name); ?></option>
            </select>
        </div>
        <div class="form-group">
            <label>Nomor Kartu Keluarga</label>
            <input type="text" class="form-control" name="no_kk"> 
        </div>
        <div class="form-group">
            <label>Nomor KTP</label>
            <input type="text" class="form-control" name="no_ktp"> 
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control" disabled>
              <option value="">-Silahkan Pilih Jenis Kelamin-</option>
             <option value="Laki-laki" <?php echo e($formulir->jenis_kelamin == 'Laki-laki'? 'selected' : ''); ?>>Laki-laki</option>
              <option value="Perempuan" <?php echo e($formulir->jenis_kelamin == 'Perempuan'? 'selected' : ''); ?>>Perempuan</option>
          </select>
      </div>
      <div class="form-group">
        <label>Pekerjaan/Unit Usaha Saat Ini</label>
        <input type="text" class="form-control" name="pekerjaan" value="<?php echo e($formulir->pekerjaan); ?>" disabled> 
    </div>
    <div class="form-group">
        <label>Nomor Handphone</label>
        <input type="text" class="form-control" name="no_hp" value="<?php echo e($formulir->no_hp); ?>" disabled> 
    </div>
    <div class="form-group">
        <label>Nomor Rekening</label>
        <input type="text" class="form-control" name="no_rek">
        <label>Nama Bank</label>
        <input type="text" class="form-control" name="bank">
        <label>Atas Nama</label>
        <input type="text" name="atas_nama" class="form-control"> 
    </div>
    <div class="form-group">
        <label>Peminatan</label>
        <select name="peminatan" class="form-control" disabled>
          <option value="">-Silahkan Pilih Peminatan-</option>
          <option value="Tata Boga" <?php echo e($formulir->peminatan == 'Tata Boga'? 'selected' : ''); ?>>Tata Boga</option>
          <option value="Las Listrik" <?php echo e($formulir->peminatan == 'Las Listrik'? 'selected' : ''); ?>>Las Listrik</option>
          <option value="Tata Rias Wajah dan Hijab" <?php echo e($formulir->peminatan == 'Tata Rias Wajah dan Hijab'? 'selected' : ''); ?>>Tata Rias Wajah dan Hijab</option>
          <option value="Financial Life Skill" <?php echo e($formulir->peminatan == 'Financial Life Skill'? 'selected' : ''); ?>>Financial Life Skill</option>
          <option value="Barista" <?php echo e($formulir->peminatan == 'Barista'? 'selected' : ''); ?>>Barista</option>
          <option value="Catering" <?php echo e($formulir->peminatan == 'Catering'? 'selected' : ''); ?>>Catering</option>
          <option value="Otomotif Service Sepeda Motor Ringan" <?php echo e($formulir->peminatan == 'Otomotif Service Sepeda Motor Ringan'? 'selected' : ''); ?>>Otomotif Service Sepeda Motor Ringan</option>
          <option value="Bakery" <?php echo e($formulir->peminatan == 'Bakery'? 'selected' : ''); ?>>Bakery</option>
          <option value="Start Up" <?php echo e($formulir->peminatan == 'Start Up'? 'selected' : ''); ?>>Start Up</option>
          <option value="Teknik Cukur Dasar" <?php echo e($formulir->peminatan == 'Teknik Cukur Dasar'? 'selected' : ''); ?>>Teknik Cukur Dasar</option>
      </select>
  </div>
  <div class="card-footer">
      <input type="submit" class="btn btn-primary" value="Simpan" name="">
      <a href="<?php echo e(url('user')); ?>" class="btn btn-default">Batal</a>
  </div>
</form>
</div>
</div>
</div>
</div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
    function onChangeSelect(url, id, name) {
            // send ajax request to get the cities of the selected province and append to the select tag
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    id: id
                },
                success: function (data) {
                    $('#' + name).empty();
                    $('#' + name).append('<option>==Pilih Salah Satu==</option>');

                    $.each(data, function (key, value) {
                        $('#' + name).append('<option value="' + key + '">' + value + '</option>');
                    });
                }
            });
        }
        $(function () {
            $('#provinsi').on('change', function () {
                onChangeSelect('<?php echo e(route("cities")); ?>', $(this).val(), 'kota');
            });
            $('#kota').on('change', function () {
                onChangeSelect('<?php echo e(route("districts")); ?>', $(this).val(), 'kecamatan');
            })
            $('#kecamatan').on('change', function () {
                onChangeSelect('<?php echo e(route("villages")); ?>', $(this).val(), 'desa');
            })
        });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/user/LengkapiData.blade.php ENDPATH**/ ?>