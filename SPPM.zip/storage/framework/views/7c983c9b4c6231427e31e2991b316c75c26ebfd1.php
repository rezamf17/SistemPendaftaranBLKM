
<?php $__env->startSection('title'); ?>
Seleksi Data
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Seleksi Data</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Seleksi Data</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <style type="text/css">
    .bootstrap-timepicker-meridian, .meridian-column
    {
        display: none;
    }
</style>
  <div class="container">
    <div class="card">
      <div class="card-header">Pilih Data Yang Ingin Di Seleksi</div>
      <div class="card-body">
        <div class="form-group">
          <form action="<?php echo e(url('SeleksiData')); ?>" method="post" accept-charset="utf-8">
            <?php echo csrf_field(); ?>
            <label>Pilih Kota/Kabupaten</label>
            <select name="id_cities" class="form-control" id="kota" onchange="change()">
              <option value="" >-Pilih Kota/Kabupaten-</option>
              <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($element->id); ?>"><?php echo e($element->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Peminatan</label>
            <select name="peminatan" class="form-control">
              <option value="">-Silahkan Pilih Peminatan-</option>
              <option value="Tata Boga">Tata Boga</option>
              <option value="Las Listrik">Las Listrik</option>
              <option value="Tata Rias Wajah dan Hijab">Tata Rias Wajah dan Hijab</option>
              <option value="Financial Life Skill">Financial Life Skill</option>
              <option value="Barista">Barista</option>
              <option value="Catering">Catering</option>
              <option value="Otomotif Service Sepeda Motor Ringan">Otomotif Service Sepeda Motor Ringan</option>
              <option value="Bakery">Bakery</option>
              <option value="Start Up">Start Up</option>
              <option value="Teknik Cukur Dasar">Teknik Cukur Dasar</option>
            </select>
            
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Seleksi</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>
  function onChangeSelect(url, id, name) {
            // send ajax request to get the cities of the selected province and append to the select tag
            $.ajax({
              url: url,
              type: 'GET',
              data: {
                id: id
              },
              success: function (data) {
                $('#' + name).empty();
                $('#' + name).append('<option>==Pilih Salah Satu==</option>');

                $.each(data, function (key, value) {
                  $('#' + name).append('<option value="' + key + '">' + value + '</option>');
                });
              }
            });
          }
          $(function () {
            // $('#provinsi').on('change', function () {
            //     onChangeSelect(' route("cities") }}', $(this).val(), 'kota');
            // });
            $('#kota').on('change', function () {
              onChangeSelect('<?php echo e(route("districts")); ?>', $(this).val(), 'kecamatan');
            })
            $('#kecamatan').on('change', function () {
              onChangeSelect('<?php echo e(route("villages")); ?>', $(this).val(), 'desa');
            })
            $('#change').on('change', function () {
              onChangeSelect('<?php echo e(route("villages")); ?>', $(this).val(), 'desa');
            })
          });
        </script>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/Seleksi.blade.php ENDPATH**/ ?>