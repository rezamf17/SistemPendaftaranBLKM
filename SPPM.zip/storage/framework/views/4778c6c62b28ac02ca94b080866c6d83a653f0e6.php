
<?php $__env->startSection('title'); ?>
Hasil Survey
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">Hasil Survey</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Hasil Survey</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Nomor Soal</th>
            <th>Soal</th>
            <th>Jawab A</th>
            <th>Jawab B</th>
            <th>Jawab C</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Program pelatihan yang dilaksanakan oleh Balai Latihan Kerja Mandiri (BLKM) menurut saudata telah sesuai dengan kurikulum?</td>
            <td><?php echo e($percentA1); ?>%</td>
            <td><?php echo e($percentB1); ?>%</td>
            <td><?php echo e($percentC1); ?>%</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Menurut saudara program pelatihan yang dilaksanakan oleh Balai Latihan Kerja Mandiri (BLKM) dapat memberikan manfaat bagi peserta lain?</td>
            <td><?php echo e($percentA2); ?>%</td>
            <td><?php echo e($percentB2); ?>%</td>
            <td><?php echo e($percentC2); ?>%</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Menurut Saudara apakah instruktur/Pengajar telah sesuai dengan kebutuhan?</td>
            <td><?php echo e($percentA3); ?>%</td>
            <td><?php echo e($percentB3); ?>%</td>
            <td><?php echo e($percentC3); ?>%</td>
          </tr>
          <tr>
            <td>4</td>
            <td>Menurut Saudara Penyampaian Materi oleh instruktur/Pengajar dengan jelas
            dan dapat dimengerti oleh Peserta Pelatihan?</td>
            <td><?php echo e($percentA4); ?>%</td>
            <td><?php echo e($percentB4); ?>%</td>
            <td><?php echo e($percentC4); ?>%</td>
          </tr>
          <tr>
            <td>5</td>
            <td>Bagaimana Menurut Saudara keterampilan Instruktur/Pengajar saat
            melakukan praktek?</td>
            <td><?php echo e($percentA5); ?>%</td>
            <td><?php echo e($percentB5); ?>%</td>
            <td><?php echo e($percentC5); ?>%</td>
          </tr>
          <tr>
            <td>6</td>
            <td>Menurut Saudara apakah Penyelenggara/Panitia dapat membantu peserta
            dalam memberikan layanan dan bimbingan pada saat praktek?</td>
            <td><?php echo e($percentA6); ?>%</td>
            <td><?php echo e($percentB6); ?>%</td>
            <td><?php echo e($percentC6); ?>%</td>
          </tr>
          <tr>
            <td>7</td>
            <td>Menurut Saudara bagaimana tanggung jawab penyelenggara/panitia
            terhadap kenyamanan peserta saat berada ditempat Pelatihan?</td>
            <td><?php echo e($percentA7); ?>%</td>
            <td><?php echo e($percentB7); ?>%</td>
            <td><?php echo e($percentC7); ?>%</td>
          </tr>
          <tr>
            <td>8</td>
            <td>Bagaimana menurut Saudara sarana dan prasarana yang diberikan oleh
            BLKM selama Pelatihan sesuai dengan kebutuhan?</td>
            <td><?php echo e($percentA8); ?>%</td>
            <td><?php echo e($percentB8); ?>%</td>
            <td><?php echo e($percentC8); ?>%</td>
          </tr>
          <tr>
            <td>9</td>
            <td>Sudah Sesuaikah Pelatihan yang saudara ikuti sekarang dengan arah minat dan bidang usaha yang sedang ditekuni?</td>
            <td><?php echo e($percentA9); ?>%</td>
            <td><?php echo e($percentB9); ?>%</td>
            <td><?php echo e($percentC9); ?>%</td>
          </tr>
          <tr>
            <td>10</td>
            <td>Apakah menurut saudara Pelatihan yang telah dilaksanakan selama berhari-hari sudah cukup?</td>
            <td><?php echo e($percentA10); ?>%</td>
            <td><?php echo e($percentB10); ?>%</td>
            <td><?php echo e($percentC10); ?>%</td>
          </tr>
          <tr>
            <td>11</td>
            <td>Program pelatihan yang dilaksanakan oleh Balai Latihan Kerja Mandiri (BLKM) menurut saudata telah sesuai dengan kurikulum?</td>
            <td><?php echo e($percentA11); ?>%</td>
            <td><?php echo e($percentB11); ?>%</td>
            <td><?php echo e($percentC11); ?>%</td>
          </tr>
        </tbody>
      </table>
    </div>
</div>
<div class="container">
  <div class="card">
    <div class="card-header"> No 12 & 13</div>
    <div class="card-body">
      <table class="table" id="example1">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Nomor Soal 12</th>
            <th>Nomor Soal 13</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($element->nama->name); ?></td>
              <td><?php echo e($element->soal_12); ?></td>
              <td><?php echo e($element->soal_13); ?></td>
              <th>
                <a href="<?php echo e(url('JawabanSurvey/'.$element->id)); ?>" class="btn btn-primary"><i class="fa fa-eye"></i>Lihat Semua Jawaban</a>
              </th>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL-PROJECT\SPPM\resources\views/admin/HasilSurvey.blade.php ENDPATH**/ ?>